(function($) {
	$('.bs-tooltip').tooltip();
})(jQuery);
